#from .model import LogisticRegression
#from .model import TwoLayerNN
from .NN import *